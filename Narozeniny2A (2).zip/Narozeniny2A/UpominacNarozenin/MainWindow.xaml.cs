﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace UpominacNarozenin
{
    /// <summary>
    /// Hlavní formulář aplikace
    /// </summary>
    public partial class MainWindow : Window
    {
        /// <summary>
        /// Inicializuje formulář
        /// </summary>
        private SpravceOsob spravceOsob = new SpravceOsob();

        public MainWindow()
        {
            InitializeComponent();
            try
            {
                spravceOsob.Nacti();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Chyba souboru", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            DataContext = spravceOsob;
        }

        private void pridatButton_Click(object sender, RoutedEventArgs e)
        {
            OsobaWindow osobaWindow = new OsobaWindow(spravceOsob);
            osobaWindow.ShowDialog();

        }
        private void odebratButton_Click(object sender, RoutedEventArgs e)
        {
            if (osobyListBox.SelectedItems != null)
            {
                try
                {
                    spravceOsob.Odeber((Osoba)osobyListBox.SelectedItem);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Chyba souboru", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                spravceOsob.Odeber((Osoba)osobyListBox.SelectedItem);
            }
        }
    }
}

       

