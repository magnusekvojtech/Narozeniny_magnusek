﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UpominacNarozenin
{

      public class Osoba
    {
        /// <summary>
        /// Celé jméno osoby
        /// </summary>
        public string Jmeno { get; set; }
        /// <summary>
        /// Datum narození
        /// </summary>
        public DateTime Narozeniny { get; set; }
        /// <summary>
        /// Věk osoby
        /// </summary>
        public int Vek
        {
            get
            {
                DateTime dnes = DateTime.Today;
                int vek = dnes.Year - Narozeniny.Year;
                if (dnes < Narozeniny.AddYears(vek))
                    vek--;
                return vek;
            }
        }
        /// <summary>
        /// Kolik dní zbývá do příštích narozenin
        /// </summary>
        public int ZbyvaDni
        {
            get
            {
                DateTime dnes = DateTime.Today;
                DateTime dalsiNarozeniny = Narozeniny.AddYears(Vek + 1);

                TimeSpan rozdil = dalsiNarozeniny - DateTime.Today;

                return Convert.ToInt32(rozdil.TotalDays);
            }
        }

        /// <summary>
        /// Nastaví novou instanci osoby
        /// </summary>
        /// <param name="jmeno">Jméno</param>
        /// <param name="narozeniny">Datum narození</param>
        public Osoba(string jmeno, DateTime narozeniny)
        {
            Jmeno = jmeno;
            Narozeniny = narozeniny;
        }

        /// <summary>
        /// Vrátí textovou reprezentaci osoby
        /// </summary>
        /// <returns>Textová reprezentace osoby</returns>
        public override string ToString()
        {
            return Jmeno;
        }

        public  Osoba()
        { 
        
        }
    }
}
