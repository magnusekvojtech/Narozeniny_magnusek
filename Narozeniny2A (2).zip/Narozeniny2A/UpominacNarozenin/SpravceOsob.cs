﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics.Eventing.Reader;
using System.IO;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace UpominacNarozenin
{
    public class SpravceOsob:INotifyPropertyChanged 
    {
        private string cesta = "osoby.xml";
         /// <summary>
         /// Údalost změny vlastnosti
         /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// Kolekce uložených osob
        /// </summary>
        public ObservableCollection<Osoba> Osoby { get; set; }
        /// <summary>
        /// Aktuální datum
        /// </summary>
        public DateTime DnesniDatum 
        {
            get 
            {
                return DateTime.Now;
            }
        }
        /// <summary>
        /// Osoba s nejbližšími narozeninami
        /// </summary>
        public Osoba NejblizsiOsoba { get; set; }

        /// <summary>
        /// Inicializuje instanci
        /// </summary>
        public SpravceOsob()
        {
            Osoby = new ObservableCollection<Osoba>();
        }

        /// <summary>
        /// Vytvoří novou osobu a přidá ji do kolekce
        /// </summary>
        /// <param name="jmeno">Jméno osoby</param>
        /// <param name="datumNarozeni">Datum narození</param>
        public void Pridej(string jmeno, DateTime? datumNarozeni)
        {            
            if (jmeno.Length < 3)
                throw new ArgumentException("Jméno je příliš krátké");
            if (datumNarozeni == null)
                throw new ArgumentException("Nebylo zadané datum narození");
            if (datumNarozeni.Value.Date > DateTime.Today)
                throw new ArgumentException("Datum narození nesmí být v budoucnosti");
            Osoba osoba = new Osoba(jmeno, datumNarozeni.Value.Date);
            Osoby.Add(osoba);
            NajdiNejblizsi();
        }

        /// <summary>
        /// Odebere osobu z kolekce
        /// </summary>
        /// <param name="osoba">Osoba k odebrání</param>
        public void Odeber(Osoba osoba)
        {
            Osoby.Remove(osoba);
            NajdiNejblizsi();
        }

        /// <summary>
        /// Najde osobu s nejbližšími narozeninami
        /// </summary>
        /// <returns>Osoba s nejbližšími narozeninami</returns>
        private void NajdiNejblizsi()
        {
            var serazeneOsoby = Osoby.OrderBy(o => o.ZbyvaDni);
            if (serazeneOsoby.Count() > 0)
                NejblizsiOsoba = serazeneOsoby.First();
            else
                NejblizsiOsoba = null;
            VyvolejZmenu("NejblizsiOsoba");
        }

        protected void VyvolejZmenu(string vlastnost)
        {
            if(PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(vlastnost));
        }

        public void Uloz()
        {
         XmlSerializer serializer = new XmlSerializer(Osoby.GetType());
            using (StreamWriter sw = new StreamWriter(cesta))
            {
                serializer.Serialize(sw, Osoby);
            }
        }
        public void Nacti() 
        {
            XmlSerializer serializer = new XmlSerializer(Osoby.GetType());
            if (File.Exists(cesta))
            {
                using(StreamReader sr=new StreamReader(cesta))
                {
                    Osoby=(ObservableCollection<Osoba>)serializer.Deserialize(sr);
                }
            }
            else
                Osoby = new ObservableCollection<Osoba>();
            NajdiNejblizsi();
        }
    }
}
